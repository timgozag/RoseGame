package com.timn.rosegame;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class StartingPoint extends Activity {

	Button kickBtn;
	Button punchBtn;
	TextView display;
	int counter;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_starting_point);
        counter = 0;
        kickBtn = (Button) findViewById(R.id.buttonKickId);
        punchBtn = (Button) findViewById(R.id.buttonPunchId);    
        display = (TextView) findViewById(R.id.textWelcomeId);
        
        kickBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				counter ++;
				display.setText("kick " + counter + " times");
			}
		});
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_starting_point, menu);
        return true;
    }
}
